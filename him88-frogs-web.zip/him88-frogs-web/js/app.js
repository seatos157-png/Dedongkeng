let customFrogs = JSON.parse(localStorage.getItem('him88_frogs_custom') || '[]');
let currentFilter = 'all';
let searchQuery = '';

const galleryGrid = document.getElementById('galleryGrid');
const emptyState = document.getElementById('emptyState');
const lightboxModal = document.getElementById('lightboxModal');
const addModal = document.getElementById('addModal');

function getAllFrogs() {
  return [...customFrogs, ...DEFAULT_FROGS];
}

function renderGallery() {
  const items = getAllFrogs().filter(frog => {
    const matchFilter = currentFilter === 'all' || frog.category === currentFilter;
    const q = searchQuery.toLowerCase();
    const matchSearch = !q ||
      frog.name.toLowerCase().includes(q) ||
      (frog.scientific && frog.scientific.toLowerCase().includes(q)) ||
      (frog.habitat && frog.habitat.toLowerCase().includes(q));
    return matchFilter && matchSearch;
  });

  if (items.length === 0) {
    galleryGrid.innerHTML = '';
    emptyState.classList.remove('hidden');
    return;
  }

  emptyState.classList.add('hidden');
  galleryGrid.innerHTML = items.map(item => `
    <article class="card" data-id="${item.id}">
      <div class="card-media">
        <img src="${item.image}" alt="${item.name}" loading="lazy"
          onerror="this.src='https://images.unsplash.com/photo-1551085254-e96b210db58a?auto=format&fit=crop&w=900&q=80'">
        <span class="card-badge">${item.category}</span>
      </div>
      <div class="card-body">
        <h3 class="card-title">${item.name}</h3>
        <p class="card-sci">${item.scientific || 'Amfibi'}</p>
        <p class="card-desc">${item.desc}</p>
      </div>
    </article>
  `).join('');

  document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('click', () => {
      openLightbox(Number(card.dataset.id));
    });
  });
}

function openLightbox(id) {
  const item = getAllFrogs().find(f => f.id === id);
  if (!item) return;

  document.getElementById('lbImage').src = item.image;
  document.getElementById('lbCategory').textContent = item.category;
  document.getElementById('lbScientific').textContent = item.scientific || '';
  document.getElementById('lbTitle').textContent = item.name;
  document.getElementById('lbHabitat').textContent = item.habitat ? `📍 Habitat: ${item.habitat}` : '';
  document.getElementById('lbDesc').textContent = item.desc;
  lightboxModal.classList.remove('hidden');
}

function closeLightbox() {
  lightboxModal.classList.add('hidden');
}

function openAddModal() {
  addModal.classList.remove('hidden');
}

function closeAddModal() {
  addModal.classList.add('hidden');
}

// Filter listeners
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    renderGallery();
  });
});

// Search listeners
['searchInput', 'searchInputMobile'].forEach(id => {
  const input = document.getElementById(id);
  if (input) {
    input.addEventListener('input', e => {
      searchQuery = e.target.value;
      renderGallery();
    });
  }
});

// Modal button & backdrop listeners
document.getElementById('btnOpenAdd').addEventListener('click', openAddModal);
document.getElementById('btnCloseAdd').addEventListener('click', closeAddModal);
document.getElementById('btnCloseLightbox').addEventListener('click', closeLightbox);

lightboxModal.addEventListener('click', e => {
  if (e.target === lightboxModal) closeLightbox();
});

addModal.addEventListener('click', e => {
  if (e.target === addModal) closeAddModal();
});

// Form submit
document.getElementById('addForm').addEventListener('submit', e => {
  e.preventDefault();
  const newFrog = {
    id: Date.now(),
    name: document.getElementById('inputName').value.trim(),
    scientific: document.getElementById('inputScientific').value.trim() || 'Spesies Kustom',
    category: 'Kustom',
    habitat: document.getElementById('inputHabitat').value.trim() || 'Koleksi Pribadi',
    image: document.getElementById('inputUrl').value.trim(),
    desc: document.getElementById('inputDesc').value.trim() || 'Ditambahkan ke koleksi him88.frogs.'
  };
  customFrogs.unshift(newFrog);
  localStorage.setItem('him88_frogs_custom', JSON.stringify(customFrogs));
  e.target.reset();
  closeAddModal();
  renderGallery();
});

renderGallery();
