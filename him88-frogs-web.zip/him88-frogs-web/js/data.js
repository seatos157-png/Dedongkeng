const DEFAULT_FROGS = [
  {
    id: 1,
    name: "Katak Pohon Mata Merah",
    scientific: "Agalychnis callidryas",
    category: "Katak Pohon",
    habitat: "Hutan Hujan Amerika Tengah",
    image: "https://images.unsplash.com/photo-1551085254-e96b210db58a?auto=format&fit=crop&w=900&q=80",
    desc: "Ikon hutan tropis dengan mata merah menyala yang digunakan untuk mengejutkan predator saat terbangun tiba-tiba."
  },
  {
    id: 2,
    name: "Katak Panah Beracun Biru",
    scientific: "Dendrobates tinctorius azureus",
    category: "Katak Eksotis",
    habitat: "Hutan Sipaliwini, Suriname",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=900&q=80",
    desc: "Warna biru elektriknya menjadi peringatan alami bagi pemangsa bahwa kulitnya menyimpan racun alkaloid."
  },
  {
    id: 3,
    name: "Kodok Bangkong Kolong",
    scientific: "Duttaphrynus melanostictus",
    category: "Kodok Darat",
    habitat: "Asia Selatan & Asia Tenggara",
    image: "https://images.unsplash.com/photo-1589652717521-10c0d092dea9?auto=format&fit=crop&w=900&q=80",
    desc: "Kodok darat berkulit kasar dengan kelenjar paratoid di belakang mata. Sangat tangguh di lingkungan tropis."
  },
  {
    id: 4,
    name: "Katak Pesek Australia",
    scientific: "Litoria caerulea",
    category: "Katak Pohon",
    habitat: "Australia & Papua",
    image: "https://images.unsplash.com/photo-1559253664-ca249d4608c6?auto=format&fit=crop&w=900&q=80",
    desc: "Dikenal dengan ekspresi wajah seperti tersenyum dan tubuh gempal berlapis lilin alami untuk menjaga kelembapan."
  },
  {
    id: 5,
    name: "Katak Kaca Transparan",
    scientific: "Hyalinobatrachium fleischmanni",
    category: "Katak Eksotis",
    habitat: "Hutan Awan Amerika Latin",
    image: "https://images.unsplash.com/photo-1579380656108-f98e4df8ea62?auto=format&fit=crop&w=900&q=80",
    desc: "Memiliki kulit perut bening sehingga organ dalam termasuk detak jantungnya dapat terlihat secara langsung."
  },
  {
    id: 6,
    name: "Kodok Eropah Biasa",
    scientific: "Bufo bufo",
    category: "Kodok Darat",
    habitat: "Padang Rumput & Hutan Eropa",
    image: "https://images.unsplash.com/photo-1504450874802-0ba2bcd9b5ae?auto=format&fit=crop&w=900&q=80",
    desc: "Lebih sering berjalan merangkak daripada melompat, dan bermigrasi massal setiap musim semi menuju kolam pemijahan."
  },
  {
    id: 7,
    name: "Katak Panah Stroberi",
    scientific: "Oophaga pumilio",
    category: "Katak Eksotis",
    habitat: "Nikaragua hingga Panama",
    image: "https://images.unsplash.com/photo-1567633090480-f19f2f67c088?auto=format&fit=crop&w=900&q=80",
    desc: "Katak mungil berwarna merah cerah dengan kaki biru yang merawat berudunya satu per satu di genangan daun bromelia."
  },
  {
    id: 8,
    name: "Katak Hijau Kolam",
    scientific: "Pelophylax kl. esculentus",
    category: "Katak Pohon",
    habitat: "Rawa & Kolam Eropa",
    image: "https://images.unsplash.com/photo-1496070242169-b672c576566b?auto=format&fit=crop&w=900&q=80",
    desc: "Perenang lincah yang gemar berjemur di atas daun teratai dan memiliki kantung suara ganda di sudut mulutnya."
  }
];
